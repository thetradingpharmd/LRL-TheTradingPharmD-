#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private LRLTheTradingPharmD[] cacheLRLTheTradingPharmD;

		
		public LRLTheTradingPharmD LRLTheTradingPharmD(bool showLRL, int minimumSwingPoints, string swingDetection, bool activeUntappedOnly, bool allowLineCrossing, double lineFitToleranceATR, int maxBarsBetweenSwings, bool showRecentOnly, int maxLRLLines, bool showLRLText, string labelSize, double maxSteepnessATR, double maxBreakATR, int swingBuffer, string aboveStyle, string aboveThickness, string belowStyle, string belowThickness, bool alertBullishLRL, bool alertBearishLRL, bool alertAnyLRL, bool alertLRLSwept, bool showLiquidityDraw, double immediateDrawRangeATR, int minimumSwingDifference, double minimumImbalanceRatio, string drawQualification, string drawPanelPosition, bool showNearestDistances, bool showUntappedSwingDots, string swingDotSize, int swingDotOffsetTicks)
		{
			return LRLTheTradingPharmD(Input, showLRL, minimumSwingPoints, swingDetection, activeUntappedOnly, allowLineCrossing, lineFitToleranceATR, maxBarsBetweenSwings, showRecentOnly, maxLRLLines, showLRLText, labelSize, maxSteepnessATR, maxBreakATR, swingBuffer, aboveStyle, aboveThickness, belowStyle, belowThickness, alertBullishLRL, alertBearishLRL, alertAnyLRL, alertLRLSwept, showLiquidityDraw, immediateDrawRangeATR, minimumSwingDifference, minimumImbalanceRatio, drawQualification, drawPanelPosition, showNearestDistances, showUntappedSwingDots, swingDotSize, swingDotOffsetTicks);
		}


		
		public LRLTheTradingPharmD LRLTheTradingPharmD(ISeries<double> input, bool showLRL, int minimumSwingPoints, string swingDetection, bool activeUntappedOnly, bool allowLineCrossing, double lineFitToleranceATR, int maxBarsBetweenSwings, bool showRecentOnly, int maxLRLLines, bool showLRLText, string labelSize, double maxSteepnessATR, double maxBreakATR, int swingBuffer, string aboveStyle, string aboveThickness, string belowStyle, string belowThickness, bool alertBullishLRL, bool alertBearishLRL, bool alertAnyLRL, bool alertLRLSwept, bool showLiquidityDraw, double immediateDrawRangeATR, int minimumSwingDifference, double minimumImbalanceRatio, string drawQualification, string drawPanelPosition, bool showNearestDistances, bool showUntappedSwingDots, string swingDotSize, int swingDotOffsetTicks)
		{
			if (cacheLRLTheTradingPharmD != null)
				for (int idx = 0; idx < cacheLRLTheTradingPharmD.Length; idx++)
					if (cacheLRLTheTradingPharmD[idx].ShowLRL == showLRL && cacheLRLTheTradingPharmD[idx].MinimumSwingPoints == minimumSwingPoints && cacheLRLTheTradingPharmD[idx].SwingDetection == swingDetection && cacheLRLTheTradingPharmD[idx].ActiveUntappedOnly == activeUntappedOnly && cacheLRLTheTradingPharmD[idx].AllowLineCrossing == allowLineCrossing && cacheLRLTheTradingPharmD[idx].LineFitToleranceATR == lineFitToleranceATR && cacheLRLTheTradingPharmD[idx].MaxBarsBetweenSwings == maxBarsBetweenSwings && cacheLRLTheTradingPharmD[idx].ShowRecentOnly == showRecentOnly && cacheLRLTheTradingPharmD[idx].MaxLRLLines == maxLRLLines && cacheLRLTheTradingPharmD[idx].ShowLRLText == showLRLText && cacheLRLTheTradingPharmD[idx].LabelSize == labelSize && cacheLRLTheTradingPharmD[idx].MaxSteepnessATR == maxSteepnessATR && cacheLRLTheTradingPharmD[idx].MaxBreakATR == maxBreakATR && cacheLRLTheTradingPharmD[idx].SwingBuffer == swingBuffer && cacheLRLTheTradingPharmD[idx].AboveStyle == aboveStyle && cacheLRLTheTradingPharmD[idx].AboveThickness == aboveThickness && cacheLRLTheTradingPharmD[idx].BelowStyle == belowStyle && cacheLRLTheTradingPharmD[idx].BelowThickness == belowThickness && cacheLRLTheTradingPharmD[idx].AlertBullishLRL == alertBullishLRL && cacheLRLTheTradingPharmD[idx].AlertBearishLRL == alertBearishLRL && cacheLRLTheTradingPharmD[idx].AlertAnyLRL == alertAnyLRL && cacheLRLTheTradingPharmD[idx].AlertLRLSwept == alertLRLSwept && cacheLRLTheTradingPharmD[idx].ShowLiquidityDraw == showLiquidityDraw && cacheLRLTheTradingPharmD[idx].ImmediateDrawRangeATR == immediateDrawRangeATR && cacheLRLTheTradingPharmD[idx].MinimumSwingDifference == minimumSwingDifference && cacheLRLTheTradingPharmD[idx].MinimumImbalanceRatio == minimumImbalanceRatio && cacheLRLTheTradingPharmD[idx].DrawQualification == drawQualification && cacheLRLTheTradingPharmD[idx].DrawPanelPosition == drawPanelPosition && cacheLRLTheTradingPharmD[idx].ShowNearestDistances == showNearestDistances && cacheLRLTheTradingPharmD[idx].ShowUntappedSwingDots == showUntappedSwingDots && cacheLRLTheTradingPharmD[idx].SwingDotSize == swingDotSize && cacheLRLTheTradingPharmD[idx].SwingDotOffsetTicks == swingDotOffsetTicks && cacheLRLTheTradingPharmD[idx].EqualsInput(input))
						return cacheLRLTheTradingPharmD[idx];
			return CacheIndicator<LRLTheTradingPharmD>(new LRLTheTradingPharmD(){ ShowLRL = showLRL, MinimumSwingPoints = minimumSwingPoints, SwingDetection = swingDetection, ActiveUntappedOnly = activeUntappedOnly, AllowLineCrossing = allowLineCrossing, LineFitToleranceATR = lineFitToleranceATR, MaxBarsBetweenSwings = maxBarsBetweenSwings, ShowRecentOnly = showRecentOnly, MaxLRLLines = maxLRLLines, ShowLRLText = showLRLText, LabelSize = labelSize, MaxSteepnessATR = maxSteepnessATR, MaxBreakATR = maxBreakATR, SwingBuffer = swingBuffer, AboveStyle = aboveStyle, AboveThickness = aboveThickness, BelowStyle = belowStyle, BelowThickness = belowThickness, AlertBullishLRL = alertBullishLRL, AlertBearishLRL = alertBearishLRL, AlertAnyLRL = alertAnyLRL, AlertLRLSwept = alertLRLSwept, ShowLiquidityDraw = showLiquidityDraw, ImmediateDrawRangeATR = immediateDrawRangeATR, MinimumSwingDifference = minimumSwingDifference, MinimumImbalanceRatio = minimumImbalanceRatio, DrawQualification = drawQualification, DrawPanelPosition = drawPanelPosition, ShowNearestDistances = showNearestDistances, ShowUntappedSwingDots = showUntappedSwingDots, SwingDotSize = swingDotSize, SwingDotOffsetTicks = swingDotOffsetTicks }, input, ref cacheLRLTheTradingPharmD);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.LRLTheTradingPharmD LRLTheTradingPharmD(bool showLRL, int minimumSwingPoints, string swingDetection, bool activeUntappedOnly, bool allowLineCrossing, double lineFitToleranceATR, int maxBarsBetweenSwings, bool showRecentOnly, int maxLRLLines, bool showLRLText, string labelSize, double maxSteepnessATR, double maxBreakATR, int swingBuffer, string aboveStyle, string aboveThickness, string belowStyle, string belowThickness, bool alertBullishLRL, bool alertBearishLRL, bool alertAnyLRL, bool alertLRLSwept, bool showLiquidityDraw, double immediateDrawRangeATR, int minimumSwingDifference, double minimumImbalanceRatio, string drawQualification, string drawPanelPosition, bool showNearestDistances, bool showUntappedSwingDots, string swingDotSize, int swingDotOffsetTicks)
		{
			return indicator.LRLTheTradingPharmD(Input, showLRL, minimumSwingPoints, swingDetection, activeUntappedOnly, allowLineCrossing, lineFitToleranceATR, maxBarsBetweenSwings, showRecentOnly, maxLRLLines, showLRLText, labelSize, maxSteepnessATR, maxBreakATR, swingBuffer, aboveStyle, aboveThickness, belowStyle, belowThickness, alertBullishLRL, alertBearishLRL, alertAnyLRL, alertLRLSwept, showLiquidityDraw, immediateDrawRangeATR, minimumSwingDifference, minimumImbalanceRatio, drawQualification, drawPanelPosition, showNearestDistances, showUntappedSwingDots, swingDotSize, swingDotOffsetTicks);
		}


		
		public Indicators.LRLTheTradingPharmD LRLTheTradingPharmD(ISeries<double> input , bool showLRL, int minimumSwingPoints, string swingDetection, bool activeUntappedOnly, bool allowLineCrossing, double lineFitToleranceATR, int maxBarsBetweenSwings, bool showRecentOnly, int maxLRLLines, bool showLRLText, string labelSize, double maxSteepnessATR, double maxBreakATR, int swingBuffer, string aboveStyle, string aboveThickness, string belowStyle, string belowThickness, bool alertBullishLRL, bool alertBearishLRL, bool alertAnyLRL, bool alertLRLSwept, bool showLiquidityDraw, double immediateDrawRangeATR, int minimumSwingDifference, double minimumImbalanceRatio, string drawQualification, string drawPanelPosition, bool showNearestDistances, bool showUntappedSwingDots, string swingDotSize, int swingDotOffsetTicks)
		{
			return indicator.LRLTheTradingPharmD(input, showLRL, minimumSwingPoints, swingDetection, activeUntappedOnly, allowLineCrossing, lineFitToleranceATR, maxBarsBetweenSwings, showRecentOnly, maxLRLLines, showLRLText, labelSize, maxSteepnessATR, maxBreakATR, swingBuffer, aboveStyle, aboveThickness, belowStyle, belowThickness, alertBullishLRL, alertBearishLRL, alertAnyLRL, alertLRLSwept, showLiquidityDraw, immediateDrawRangeATR, minimumSwingDifference, minimumImbalanceRatio, drawQualification, drawPanelPosition, showNearestDistances, showUntappedSwingDots, swingDotSize, swingDotOffsetTicks);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.LRLTheTradingPharmD LRLTheTradingPharmD(bool showLRL, int minimumSwingPoints, string swingDetection, bool activeUntappedOnly, bool allowLineCrossing, double lineFitToleranceATR, int maxBarsBetweenSwings, bool showRecentOnly, int maxLRLLines, bool showLRLText, string labelSize, double maxSteepnessATR, double maxBreakATR, int swingBuffer, string aboveStyle, string aboveThickness, string belowStyle, string belowThickness, bool alertBullishLRL, bool alertBearishLRL, bool alertAnyLRL, bool alertLRLSwept, bool showLiquidityDraw, double immediateDrawRangeATR, int minimumSwingDifference, double minimumImbalanceRatio, string drawQualification, string drawPanelPosition, bool showNearestDistances, bool showUntappedSwingDots, string swingDotSize, int swingDotOffsetTicks)
		{
			return indicator.LRLTheTradingPharmD(Input, showLRL, minimumSwingPoints, swingDetection, activeUntappedOnly, allowLineCrossing, lineFitToleranceATR, maxBarsBetweenSwings, showRecentOnly, maxLRLLines, showLRLText, labelSize, maxSteepnessATR, maxBreakATR, swingBuffer, aboveStyle, aboveThickness, belowStyle, belowThickness, alertBullishLRL, alertBearishLRL, alertAnyLRL, alertLRLSwept, showLiquidityDraw, immediateDrawRangeATR, minimumSwingDifference, minimumImbalanceRatio, drawQualification, drawPanelPosition, showNearestDistances, showUntappedSwingDots, swingDotSize, swingDotOffsetTicks);
		}


		
		public Indicators.LRLTheTradingPharmD LRLTheTradingPharmD(ISeries<double> input , bool showLRL, int minimumSwingPoints, string swingDetection, bool activeUntappedOnly, bool allowLineCrossing, double lineFitToleranceATR, int maxBarsBetweenSwings, bool showRecentOnly, int maxLRLLines, bool showLRLText, string labelSize, double maxSteepnessATR, double maxBreakATR, int swingBuffer, string aboveStyle, string aboveThickness, string belowStyle, string belowThickness, bool alertBullishLRL, bool alertBearishLRL, bool alertAnyLRL, bool alertLRLSwept, bool showLiquidityDraw, double immediateDrawRangeATR, int minimumSwingDifference, double minimumImbalanceRatio, string drawQualification, string drawPanelPosition, bool showNearestDistances, bool showUntappedSwingDots, string swingDotSize, int swingDotOffsetTicks)
		{
			return indicator.LRLTheTradingPharmD(input, showLRL, minimumSwingPoints, swingDetection, activeUntappedOnly, allowLineCrossing, lineFitToleranceATR, maxBarsBetweenSwings, showRecentOnly, maxLRLLines, showLRLText, labelSize, maxSteepnessATR, maxBreakATR, swingBuffer, aboveStyle, aboveThickness, belowStyle, belowThickness, alertBullishLRL, alertBearishLRL, alertAnyLRL, alertLRLSwept, showLiquidityDraw, immediateDrawRangeATR, minimumSwingDifference, minimumImbalanceRatio, drawQualification, drawPanelPosition, showNearestDistances, showUntappedSwingDots, swingDotSize, swingDotOffsetTicks);
		}

	}
}

#endregion
